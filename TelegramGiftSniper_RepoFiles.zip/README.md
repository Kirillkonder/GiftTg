# TelegramGiftSniper

🎯 **Авто-ловушка для Telegram Marketplace подарков**  
Ловит подарки при падении цены ниже заданного лимита. Работает с Telegram Desktop на Windows.

## ⚙️ Возможности
- Поддержка всех актуальных подарков
- Интерфейс RU/EN
- Быстрое автоопределение окна Telegram
- Реакция < 0.6 секунды
- Статистика и лог действий
- Сохранение лимитов между сессиями
- Portable .exe (не требует установки)

## 📥 Как пользоваться
1. Запусти Telegram Desktop и открой маркет с подарками.
2. Запусти `TelegramGiftSniper.exe`.
3. Укажи лимит (в рублях) вручную.
4. Программа начнёт мониторинг и автонажатие «Купить», если цена ниже лимита.

## 📊 Поддерживаемые подарки
- B-Day Candle
- Desk Calendar
- Lol Pop
- Party Spakler
- Lunar Snaker
- Jack-in-the-Box
- Easter Egg
- Big Year
- Xmas Stocking
- Cookie Heart
- Spy Agaric
- Eternal Candle
- Witch Hat
- Spiced Wine
- Ginger Cookie
- Winter Wreath
- Santa Hat
- Jingle Bells
- Holiday Drink

## 🛡 Безопасность
- Не подключается к интернету
- Не собирает данные
- Не взаимодействует с Telegram API — работает только через экран

## 📄 Лицензия
MIT
